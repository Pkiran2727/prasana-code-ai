"""DB pool + auth dependency. DATABASE_URL env var లో Postgres connection string ఉండాలి."""
import os
from contextlib import contextmanager
from psycopg2.pool import ThreadedConnectionPool
from psycopg2.extras import RealDictCursor
from fastapi import Header, HTTPException

_pool = ThreadedConnectionPool(1, 10, dsn=os.environ["DATABASE_URL"])


@contextmanager
def get_cursor():
    """ఒక transaction: success అయితే commit, error వస్తే rollback."""
    conn = _pool.getconn()
    try:
        with conn.cursor(cursor_factory=RealDictCursor) as cur:
            yield cur
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        _pool.putconn(conn)


def get_current_user_id(authorization: str = Header(None)) -> str:
    """TODO: మీ existing auth (Supabase JWT verify) తో replace చేయండి.
    ఇది user UUID (auth.users.id) string గా return చేయాలి."""
    if not authorization:
        raise HTTPException(401, "Not authenticated")
    raise NotImplementedError("Wire this to your existing Supabase JWT verification")
