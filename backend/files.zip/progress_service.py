import time
from entitlement import EFFECTIVE_PREMIUM_SQL


# ---------- Sandbox adapter ----------
def run_code(code: str, stdin: str, timeout_ms: int) -> dict:
    """TODO: మీ existing sandbox runner కి connect చేయండి.
    Return: {"stdout": str, "stderr": str, "timed_out": bool, "runtime_ms": int}"""
    from sandbox_runner import run_python  # <-- మీ అసలు function పేరు/signature కి మార్చండి
    start = time.time()
    out = run_python(code, stdin=stdin, timeout=timeout_ms / 1000)
    return {
        "stdout": out.get("stdout", ""),
        "stderr": out.get("stderr", ""),
        "timed_out": out.get("timed_out", False),
        "runtime_ms": int((time.time() - start) * 1000),
    }


def _norm(s: str) -> str:
    return "\n".join(line.rstrip() for line in (s or "").strip().splitlines())


def run_tests(cur, lesson_id: str, code: str, only_visible: bool):
    cur.execute("SELECT time_limit_ms FROM challenges WHERE lesson_id=%s", (lesson_id,))
    ch = cur.fetchone()
    q = "SELECT * FROM test_cases WHERE lesson_id=%s"
    if only_visible:
        q += " AND is_hidden = FALSE"
    cur.execute(q + " ORDER BY sort_order", (lesson_id,))
    tests = cur.fetchall()

    results, passed, max_rt = [], 0, 0
    for t in tests:
        r = run_code(code, t["input_data"], ch["time_limit_ms"])
        ok = (not r["timed_out"]) and _norm(r["stdout"]) == _norm(t["expected_output"])
        passed += ok
        max_rt = max(max_rt, r["runtime_ms"])
        item = {"passed": ok, "hidden": t["is_hidden"], "timed_out": r["timed_out"]}
        if not t["is_hidden"]:  # hidden tests వివరాలు ఎప్పుడూ లీక్ చేయకూడదు
            item.update(input=t["input_data"], expected=t["expected_output"],
                        actual=r["stdout"], error=r["stderr"])
        results.append(item)
    return {"passed": bool(tests) and passed == len(tests), "tests_passed": passed,
            "tests_total": len(tests), "runtime_ms": max_rt, "results": results}


def get_lesson_access(cur, lesson_id: str):
    cur.execute(f"""
        SELECT l.*, c.slug AS course_slug, {EFFECTIVE_PREMIUM_SQL} AS effective_premium
        FROM lessons l JOIN modules m ON m.id=l.module_id JOIN courses c ON c.id=m.course_id
        WHERE l.id=%s AND l.is_published AND c.is_published""", (lesson_id,))
    return cur.fetchone()


# ---------- Progress + XP (idempotent) ----------
def record_attempt(cur, user_id: str, lesson_id: str, code: str):
    cur.execute("""
        INSERT INTO user_progress (user_id, lesson_id, status, attempts, last_code)
        VALUES (%s,%s,'in_progress',1,%s)
        ON CONFLICT (user_id, lesson_id) DO UPDATE
          SET attempts = user_progress.attempts + 1, last_code = EXCLUDED.last_code, updated_at = now()""",
        (user_id, lesson_id, code))


def complete_lesson(cur, user_id: str, lesson_id: str, xp_reward: int) -> int:
    """మొదటిసారి మాత్రమే XP ఇస్తుంది. Awarded XP return చేస్తుంది (రెండోసారి 0)."""
    cur.execute("""INSERT INTO user_progress (user_id, lesson_id, status)
                   VALUES (%s,%s,'in_progress') ON CONFLICT DO NOTHING""", (user_id, lesson_id))
    cur.execute("SELECT status FROM user_progress WHERE user_id=%s AND lesson_id=%s FOR UPDATE",
                (user_id, lesson_id))
    if cur.fetchone()["status"] == "completed":
        return 0
    cur.execute("""UPDATE user_progress SET status='completed', xp_earned=%s,
                   completed_at=now(), updated_at=now() WHERE user_id=%s AND lesson_id=%s""",
                (xp_reward, user_id, lesson_id))
    cur.execute("UPDATE user_profiles SET total_xp = total_xp + %s WHERE id=%s", (xp_reward, user_id))
    return xp_reward
